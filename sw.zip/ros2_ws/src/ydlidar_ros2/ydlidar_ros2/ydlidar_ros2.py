import rclpy
from rclpy.node import Node
import numpy as np
import cv2
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan
import math

RAD2DEG = lambda x: x * 180.0 / math.pi
DISTANCE = 1.00  # 인식범위 반지름 정의
MINDISTANCE = 0.1  # 최소 거리 정의
ZERODISTANCE = 0.6  # 정지 제로턴 거리 정의


class YDLidarScanSubscriber(Node):
    def __init__(self):
        super().__init__('ydlidar_scan_subscriber')
        self.error = 0.0
        self.min_distance_R = 0.0
        self.min_distance_L = 0.0
        self.count_ = 0

        qos_profile = rclpy.qos.QoSProfile(depth=10)
        self.ydlidar_subscriber_ = self.create_subscription(
            LaserScan,
            'scan',
            self.scan_callback,
            rclpy.qos.qos_profile_sensor_data
        )

        self.dynamixel_publisher_ = self.create_publisher(Twist, 'cmd_vel', qos_profile)
        self.timer_ = self.create_timer(0.1, self.publish_velcmd_msg)

    def scan_callback(self, scan):
        if not scan.ranges:
            self.get_logger().error('LIDAR scan data is empty')
            return

        lidar = np.full((600, 600, 3), 255, np.uint8)
        cv2.arrowedLine(lidar, (lidar.shape[1] // 2, lidar.shape[0] // 2),
                        (lidar.shape[1] // 2, lidar.shape[0] // 2 - int(DISTANCE * 100)), (0, 255, 255), 2)

        count = min(int(scan.scan_time / scan.time_increment), len(scan.ranges))
        flag_R, flag_L = False, False
        distance_R, angle_R, distance_L, angle_L = [], [], [], []
        distance_pts_R, distance_pts_L = [], []

        for i in range(count):
            degree = RAD2DEG(scan.angle_min + scan.angle_increment * i)
            lidar_range = scan.ranges[i]
            range_x = lidar.shape[1] // 2 - int((lidar_range / 3) * math.cos(degree * math.pi / 180.0) * (lidar.shape[1] // 2))
            range_y = lidar.shape[0] // 2 - int((lidar_range / 3) * math.sin(degree * math.pi / 180.0) * (lidar.shape[0] // 2))

            if -30 <= degree <= 30:
                if MINDISTANCE <= lidar_range < DISTANCE:
                    if degree < 0:
                        distance_R.append(lidar_range)
                        distance_pts_R.append((range_y, range_x))
                        angle_R.append(degree)
                        flag_R = True
                    else:
                        distance_L.append(lidar_range)
                        distance_pts_L.append((range_y, range_x))
                        angle_L.append(degree)
                        flag_L = True
                    cv2.circle(lidar, (range_y, range_x), 1, (0, 0, 255), -1)
                else:
                    cv2.circle(lidar, (range_y, range_x), 1, (0, 0, 255), -1)
            else:
                cv2.circle(lidar, (range_y, range_x), 1, (255, 0, 0), -1)

        self.min_distance_L = min(distance_L) if distance_L else float('inf')
        self.min_distance_R = min(distance_R) if distance_R else float('inf')

        if flag_L and flag_R:
            min_index_L = distance_L.index(self.min_distance_L)
            min_index_R = distance_R.index(self.min_distance_R)
            cv2.arrowedLine(lidar, (lidar.shape[1] // 2, lidar.shape[0] // 2), distance_pts_L[min_index_L], (0, 255, 0), 2)
            cv2.arrowedLine(lidar, (lidar.shape[1] // 2, lidar.shape[0] // 2), distance_pts_R[min_index_R], (255, 0, 0), 2)
            angle = angle_R[min_index_R] + angle_L[min_index_L]
            if angle != 0:
                self.error = ((DISTANCE * 100 - distance_pts_L[min_index_L][0]) - 
                              (distance_pts_R[min_index_R][0] - (DISTANCE * 100 + lidar.shape[1] // 2))) / 2
            else:
                self.error = ((lidar.shape[1] // 2 + DISTANCE * 100) - distance_pts_R[min_index_R][0] -
                              (distance_pts_L[min_index_L][0] - (lidar.shape[1] // 2 - DISTANCE * 100))) / 2
        elif flag_R and not flag_L:
            min_index_R = distance_R.index(self.min_distance_R)
            cv2.arrowedLine(lidar, (lidar.shape[1] // 2, lidar.shape[0] // 2), distance_pts_R[min_index_R], (255, 0, 0), 2)
            self.error = (lidar.shape[1] // 2 + DISTANCE * 100) - distance_pts_R[min_index_R][0]
        elif not flag_R and flag_L:
            min_index_L = distance_L.index(self.min_distance_L)
            cv2.arrowedLine(lidar, (lidar.shape[1] // 2, lidar.shape[0] // 2), distance_pts_L[min_index_L], (0, 255, 0), 2)
            self.error = -(distance_pts_L[min_index_L][0] - (lidar.shape[1] // 2 - DISTANCE * 100))
        else:
            cv2.arrowedLine(lidar, (lidar.shape[1] // 2, lidar.shape[0] // 2),
                            (lidar.shape[1] // 2 + int(DISTANCE * 100), lidar.shape[0] // 2), (255, 0, 0), 2)
            cv2.arrowedLine(lidar, (lidar.shape[1] // 2, lidar.shape[0] // 2),
                            (lidar.shape[1] // 2 - int(DISTANCE * 100), lidar.shape[0] // 2), (255, 0, 0), 2)
            self.error = 0.0

        if self.error > 0:
            self.get_logger().info(f'현재 좌회전중 error: {self.error / 2.0}')
        elif self.error < 0:
            self.get_logger().info(f'현재 우회전중 error: {self.error / 2.0}')
        else:
            self.get_logger().info(f'현재 직진중 error: {self.error / 2.0}')

        cv2.imshow("lidar", lidar)
        cv2.waitKey(10)

    def publish_velcmd_msg(self):
        msg = Twist()

        if self.min_distance_R < ZERODISTANCE or self.min_distance_L < ZERODISTANCE:
            msg.linear.x = 0.0
        else:
            msg.linear.x = 60.0

        msg.angular.z = self.error / 2.0
        self.dynamixel_publisher_.publish(msg)
        self.get_logger().info(f'cmd_vel 메시지 발행: linear.x = {msg.linear.x}, angular.z = {msg.angular.z}')


def main(args=None):
    rclpy.init(args=args)
    node = YDLidarScanSubscriber()
    rclpy.spin(node)
    rclpy.shutdown()


if __name__ == '__main__':
    main()
