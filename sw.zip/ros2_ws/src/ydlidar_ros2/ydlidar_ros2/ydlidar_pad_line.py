import rclpy
from rclpy.node import Node
import numpy as np
import cv2
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan
import pygame
import math
from std_msgs.msg import Int32

RAD2DEG = lambda x: x * 180.0 / math.pi
DISTANCE = 1.00  # 인식범위 반지름 정의
MINDISTANCE = 0.1  # 최소 거리 정의
ZERODISTANCE = 0.6  # 정지 제로턴 거리 정의

class PadController(Node):
    def __init__(self):
        super().__init__('pad_controller')
        self.publisher_ = self.create_publisher(Twist, 'cmd_vel', 10)
        self.timer = self.create_timer(0.1, self.timer_callback)

        pygame.init()
        pygame.joystick.init()

        joystick_count = pygame.joystick.get_count()
        self.get_logger().info(f"Number of joysticks: {joystick_count}")

        # Xbox One S Controller 찾기 및 초기화
        self.joystick = None
        for i in range(joystick_count):
            js = pygame.joystick.Joystick(i)
            js.init()
            self.get_logger().info(f"Joystick {i} name: {js.get_name()}")
            if 'Xbox One S Controller' in js.get_name():
                self.joystick = js
                self.get_logger().info(f"Selected joystick: {js.get_name()} at index {i}")
                break

        if self.joystick is None:
            self.get_logger().error("Xbox One S Controller not found")
            exit()

        self.get_logger().info(f"Using joystick: {self.joystick.get_name()}")
        self.get_logger().info(f"Number of axes: {self.joystick.get_numaxes()}")
        self.get_logger().info(f"Number of buttons: {self.joystick.get_numbuttons()}")
        self.get_logger().info(f"Number of hats: {self.joystick.get_numhats()}")

        # LIDAR 관련 초기화
        self.error = 0.0
        self.min_distance_R = 0.0
        self.min_distance_L = 0.0
        self.create_subscription(LaserScan, 'scan', self.scan_callback, rclpy.qos.qos_profile_sensor_data)

        # Line Detector 모드 초기화
        self.line_detector_node = None

    def timer_callback(self):
        pygame.event.pump()

        # 축 값 읽기
        axis_values = [self.joystick.get_axis(i) for i in range(self.joystick.get_numaxes())]

        # 축 3의 값을 확인하여 모드 설정
        axis_3_value = axis_values[3]
        if -0.5 <= axis_3_value <= 0.5:
            self.mode = 0  # 패드 모드
        elif 0.5 < axis_3_value <= 1.0:
            self.mode = 1  # LIDAR 모드
        elif -1.0 <= axis_3_value < -0.5:
            self.mode = 2  # Line Detector 모드

        # 모드에 따라 해당 기능 실행
        if self.mode == 0:
            self.run_pad_controller(axis_values)
        elif self.mode == 1:
            self.run_lidar_controller()
        elif self.mode == 2:
            if self.line_detector_node is None:
                self.start_line_detector_mode()
            pass  # Line Detector 모드는 별도로 동작함

        # Line Detector 모드 종료 처리 (패드 모드나 LIDAR 모드로 전환 시)
        if self.mode != 2 and self.line_detector_node is not None:
            self.line_detector_node.destroy_node()
            self.line_detector_node = None

    def run_pad_controller(self, axis_values):
        # Hat 값 읽기
        hat_values = [self.joystick.get_hat(i) for i in range(self.joystick.get_numhats())]

        # Twist 메시지 작성 및 발행
        msg = Twist()

        # 축 4와 축 5에 따른 msg.linear.x 설정
        if axis_values[4] > 0.9:
            msg.linear.x = 1.0
        elif -0.9 < axis_values[4] <= 0.9:
            msg.linear.x = 0.5
        elif -0.9 < axis_values[5] <= 0.9:
            msg.linear.x = -0.5
        elif axis_values[5] >= 0.9:
            msg.linear.x = -1.0
        else:
            msg.linear.x = 0.0

        # 축 0을 msg.angular.z로 설정
        if axis_values[0] <= 0.15 and axis_values[0] >= -0.15:
            msg.angular.z = 0.0
        else:
            msg.angular.z = float(axis_values[0])

        # Hat 값에 따른 msg.angular.x 설정
        if hat_values[0] == (0, 0):
            msg.angular.x = 0.0
        elif hat_values[0] == (1, 0):
            msg.angular.x = 1.0
        elif hat_values[0] == (-1, 0):
            msg.angular.x = -1.0
        elif hat_values[0] == (0, 1):
            msg.angular.x = 2.0
        elif hat_values[0] == (0, -1):
            msg.angular.x = -2.0
        elif hat_values[0] == (1, 1):
            msg.angular.x = 3.0
        elif hat_values[0] == (-1, -1):
            msg.angular.x = -3.0

        # 버튼에 따른 msg.linear.z 설정
        msg.linear.z = 0.0
        for i, pressed in enumerate(self.joystick.get_button(i) for i in range(self.joystick.get_numbuttons())):
            if pressed:
                msg.linear.z = float(i + 1)
                break

        self.publisher_.publish(msg)

        # 패드의 상태를 한 줄로 출력
        self.get_logger().info(
            f"Pad Mode - Axis values: {axis_values}, Hat values: {hat_values}, Linear: {msg.linear.x}, Angular.z: {msg.angular.z}, Angular.x: {msg.angular.x}, Button: {msg.linear.z}")

    def run_lidar_controller(self):
        # LIDAR 스캔 데이터를 기반으로 로봇을 제어하는 로직
        lidar = np.full((600, 600, 3), 255, np.uint8)
        cv2.arrowedLine(lidar, (lidar.shape[1] // 2, lidar.shape[0] // 2),
                        (lidar.shape[1] // 2, lidar.shape[0] // 2 - int(DISTANCE * 100)), (0, 255, 255), 2)

        # LIDAR 데이터가 없는 경우 실행하지 않음
        if not hasattr(self, 'latest_scan'):
            return

        scan = self.latest_scan  # 최신 LIDAR 데이터를 사용
        count = min(int(scan.scan_time / scan.time_increment), len(scan.ranges))  # scan.ranges의 길이로 제한
        flag_R, flag_L = False, False
        distance_R, angle_R, distance_L, angle_L = [], [], [], []
        distance_pts_R, distance_pts_L = [], []

        for i in range(count):
            degree = RAD2DEG(scan.angle_min + scan.angle_increment * i)
            lidar_range = scan.ranges[i]
            range_x = lidar.shape[1] // 2 - int((lidar_range / 3) * math.cos(degree * math.pi / 180.0) * (lidar.shape[1] // 2))
            range_y = lidar.shape[0] // 2 - int((lidar_range / 3) * math.sin(degree * math.pi / 180.0) * (lidar.shape[0] // 2))

            if -30 <= degree <= 30:
                if MINDISTANCE <= lidar_range < DISTANCE:
                    if degree < 0:
                        distance_R.append(lidar_range)
                        distance_pts_R.append((range_y, range_x))
                        angle_R.append(degree)
                        flag_R = True
                    else:
                        distance_L.append(lidar_range)
                        distance_pts_L.append((range_y, range_x))
                        angle_L.append(degree)
                        flag_L = True
                    cv2.circle(lidar, (range_y, range_x), 1, (0, 0, 255), -1)
                else:
                    cv2.circle(lidar, (range_y, range_x), 1, (0, 0, 255), -1)
            else:
                cv2.circle(lidar, (range_y, range_x), 1, (255, 0, 0), -1)

        self.min_distance_L = min(distance_L) if distance_L else float('inf')
        self.min_distance_R = min(distance_R) if distance_R else float('inf')

        if flag_L and flag_R:
            min_index_L = distance_L.index(self.min_distance_L)
            min_index_R = distance_R.index(self.min_distance_R)
            cv2.arrowedLine(lidar, (lidar.shape[1] // 2, lidar.shape[0] // 2), distance_pts_L[min_index_L], (0, 255, 0), 2)
            cv2.arrowedLine(lidar, (lidar.shape[1] // 2, lidar.shape[0] // 2), distance_pts_R[min_index_R], (255, 0, 0), 2)
            angle = angle_R[min_index_R] + angle_L[min_index_L]
            if angle != 0:
                self.error = ((DISTANCE * 100 - distance_pts_L[min_index_L][0]) -
                              (distance_pts_R[min_index_R][0] - (DISTANCE * 100 + lidar.shape[1] // 2))) / 2
            else:
                self.error = ((lidar.shape[1] // 2 + DISTANCE * 100) - distance_pts_R[min_index_R][0] -
                              (distance_pts_L[min_index_L][0] - (lidar.shape[1] // 2 - DISTANCE * 100))) / 2
        elif flag_R and not flag_L:
            min_index_R = distance_R.index(self.min_distance_R)
            cv2.arrowedLine(lidar, (lidar.shape[1] // 2, lidar.shape[0] // 2), distance_pts_R[min_index_R], (255, 0, 0), 2)
            self.error = (lidar.shape[1] // 2 + DISTANCE * 100) - distance_pts_R[min_index_R][0]
        elif not flag_R and flag_L:
            min_index_L = distance_L.index(self.min_distance_L)
            cv2.arrowedLine(lidar, (lidar.shape[1] // 2, lidar.shape[0] // 2), distance_pts_L[min_index_L], (0, 255, 0), 2)
            self.error = -(distance_pts_L[min_index_L][0] - (lidar.shape[1] // 2 - DISTANCE * 100))
        else:
            cv2.arrowedLine(lidar, (lidar.shape[1] // 2, lidar.shape[0] // 2),
                            (lidar.shape[1] // 2 + int(DISTANCE * 100), lidar.shape[0] // 2), (255, 0, 0), 2)
            cv2.arrowedLine(lidar, (lidar.shape[1] // 2, lidar.shape[0] // 2),
                            (lidar.shape[1] // 2 - int(DISTANCE * 100), lidar.shape[0] // 2), (255, 0, 0), 2)
            self.error = 0.0

        if self.error > 0:
            self.get_logger().info(f'현재 좌회전중 error: {self.error / 2.0}')
        elif self.error < 0:
            self.get_logger().info(f'현재 우회전중 error: {self.error / 2.0}')
        else:
            self.get_logger().info(f'현재 직진중 error: {self.error / 2.0}')

        cv2.imshow("lidar", lidar)
        cv2.waitKey(10)

        self.publish_velcmd_msg()

    def publish_velcmd_msg(self):
        msg = Twist()

        if self.min_distance_R < ZERODISTANCE or self.min_distance_L < ZERODISTANCE:
            msg.linear.x = 30.0
        else:
            msg.linear.x = 60.0

        msg.angular.z = self.error / 2.0
        # lidar모드일때 linear.z값 20 고정
        msg.linear.z = 20.0
        self.publisher_.publish(msg)
        self.get_logger().info(f'cmd_vel 메시지 발행: linear.x = {msg.linear.x}, angular.z = {msg.angular.z}')

    def scan_callback(self, scan):
        # 최신 LIDAR 데이터를 저장하여, 필요할 때 사용
        self.latest_scan = scan

    def start_line_detector_mode(self):
        if self.line_detector_node is None:
            self.line_detector_node = LineDetectorNode()
            rclpy.get_global_executor().add_node(self.line_detector_node)
            self.get_logger().info("Line Detector 모드 시작")

class LineDetectorNode(Node):
    def __init__(self):
        super().__init__("line_detector_node")
        self.publisher_ = self.create_publisher(Int32, "lowest_line_height", 10)
        self.timer_ = self.create_timer(
            0.03, self.process_frame)
        self.cap_ = cv2.VideoCapture(0)

    def process_frame(self):
        if not self.cap_.isOpened():
            self.get_logger().error("카메라를 열 수 없습니다.")
            return

        ret, frame = self.cap_.read()
        if not ret or frame is None:
            return

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        gray = cv2.GaussianBlur(gray, (5, 5), 2)
        edge = cv2.Canny(gray, 50, 150, 3)

        lines = cv2.HoughLinesP(edge, 1, np.pi/180, 200, minLineLength=50, maxLineGap=10)

        if lines is not None:  # lines가 None이 아닌 경우에만 처리
            min_angle = -10.0 * (np.pi / 180.0)
            max_angle = 10.0 * (np.pi / 180.0)

            lowest_line_y = 0
            horizontal_lines = []

            for l in lines:
                x1, y1, x2, y2 = l[0]
                angle = np.arctan2(y2 - y1, x2 - x1)

                if min_angle < angle < max_angle:
                    horizontal_lines.append((x1, y1, x2, y2))
                    lowest_line_y = max(lowest_line_y, y1, y2)

            # 선 그룹화
            merged_lines = []
            height_threshold = 10

            for l1 in horizontal_lines:
                merged = False
                for i, l2 in enumerate(merged_lines):
                    if abs(l1[1] - l2[1]) < height_threshold and abs(l1[3] - l2[3]) < height_threshold:
                        l2[0] = min(l2[0], l1[0])
                        l2[1] = (l2[1] + l1[1]) // 2
                        l2[2] = max(l2[2], l1[2])
                        l2[3] = (l2[3] + l1[3]) // 2
                        merged = True
                        break

                if not merged:
                    merged_lines.append(list(l1))

            for x1, y1, x2, y2 in merged_lines:
                cv2.line(frame, (x1, y1), (x2, y2), (0, 0, 255), 3)

            if lowest_line_y > 0:
                self.get_logger().info(f"가장 낮은 가로선의 높이: {lowest_line_y}")
                msg = Int32()
                if 500 < lowest_line_y:
                    msg.data = 0
                else:
                    msg.data = 1
                self.publisher_.publish(msg)

        cv2.imshow("Frame", frame)
        cv2.waitKey(30)

    def destroy_node(self):
        if self.cap_.isOpened():
            self.cap_.release()  # 카메라 리소스를 해제
            cv2.destroyAllWindows()  # OpenCV 윈도우를 닫음
        super().destroy_node()

def main(args=None):
    rclpy.init(args=args)
    node = PadController()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()