import rclpy
from rclpy.node import Node
import numpy as np
import cv2
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan
import pygame
import math

RAD2DEG = lambda x: x * 180.0 / math.pi
DISTANCE = 1.00  # 인식범위 반지름 정의
MINDISTANCE = 0.1  # 최소 거리 정의
ZERODISTANCE = 0.6  # 정지 제로턴 거리 정의


class PadController(Node):
    def __init__(self):
        super().__init__('pad_controller')
        self.publisher_ = self.create_publisher(Twist, 'cmd_vel', 10)
        self.timer = self.create_timer(0.1, self.timer_callback)

        pygame.init()
        pygame.joystick.init()

        joystick_count = pygame.joystick.get_count()
        self.get_logger().info(f"Number of joysticks: {joystick_count}")

        # Xbox One S Controller 찾기 및 초기화
        self.joystick = None
        for i in range(joystick_count):
            js = pygame.joystick.Joystick(i)
            js.init()
            self.get_logger().info(f"Joystick {i} name: {js.get_name()}")
            if 'Xbox One S Controller' in js.get_name():
                self.joystick = js
                self.get_logger().info(f"Selected joystick: {js.get_name()} at index {i}")
                break

        if self.joystick is None:
            self.get_logger().error("Xbox One S Controller not found")
            exit()

        self.get_logger().info(f"Using joystick: {self.joystick.get_name()}")
        self.get_logger().info(f"Number of axes: {self.joystick.get_numaxes()}")
        self.get_logger().info(f"Number of buttons: {self.joystick.get_numbuttons()}")
        self.get_logger().info(f"Number of hats: {self.joystick.get_numhats()}")

        # 버튼 15 눌림 횟수를 추적할 변수
        self.button_15_press_count = 0
        self.is_pad_mode = True  # 초기 모드는 패드 모드

        # LIDAR 관련 초기화
        self.error = 0.0
        self.min_distance_R = 0.0
        self.min_distance_L = 0.0
        self.create_subscription(LaserScan, 'scan', self.scan_callback, rclpy.qos.qos_profile_sensor_data)

    def timer_callback(self):
        pygame.event.pump()

        # 버튼 값 읽기
        button_values = [self.joystick.get_button(i) for i in range(self.joystick.get_numbuttons())]

        # 버튼 15가 눌렸는지 확인
        if button_values[14]:  # 버튼 숫자 확인
            self.button_15_press_count += 1
            self.get_logger().info(f"Button 15 pressed {self.button_15_press_count} times")
            self.is_pad_mode = self.button_15_press_count % 2 == 0

        if self.is_pad_mode:
            self.run_pad_controller(button_values)
        else:
            self.run_lidar_controller()

    def run_pad_controller(self, button_values):
        # 축 값 읽기
        axis_values = [self.joystick.get_axis(i) for i in range(self.joystick.get_numaxes())]
        # 축 값이 -0.11에서 0.11 사이일 때 0으로 설정
        axis_values = [0.0 if -0.11 <= value <= 0.11 else value for value in axis_values]

        # Hat 값 읽기
        hat_values = [self.joystick.get_hat(i) for i in range(self.joystick.get_numhats())]

        # Twist 메시지 작성 및 발행
        msg = Twist()

        # 축 4와 축 5에 따른 msg.linear.x 설정
        if axis_values[4] > 0.9:
            msg.linear.x = 1.0
        elif -0.9 < axis_values[4] <= 0.9:
            msg.linear.x = 0.5
        elif -0.9 < axis_values[5] <= 0.9:
            msg.linear.x = -0.5
        elif axis_values[5] >= 0.9:
            msg.linear.x = -1.0
        else:
            msg.linear.x = 0.0

        # 축 0을 msg.angular.z로 설정
        msg.angular.z = float(axis_values[0])

        # Hat 값에 따른 msg.angular.x 설정
        if hat_values[0] == (0, 0):
            msg.angular.x = 0.0
        elif hat_values[0] == (1, 0):
            msg.angular.x = 1.0
        elif hat_values[0] == (-1, 0):
            msg.angular.x = -1.0
        elif hat_values[0] == (0, 1):
            msg.angular.x = 2.0
        elif hat_values[0] == (0, -1):
            msg.angular.x = -2.0
        elif hat_values[0] == (1, 1):
            msg.angular.x = 3.0
        elif hat_values[0] == (-1, -1):
            msg.angular.x = -3.0

        # 버튼에 따른 msg.linear.z 설정
        msg.linear.z = 0.0
        for i, pressed in enumerate(button_values):
            if pressed:
                msg.linear.z = float(i + 1)
                break

        self.publisher_.publish(msg)

        # 패드의 상태를 한 줄로 출력
        self.get_logger().info(
            f"Pad Mode - Axis values: {axis_values}, Button values: {button_values}, Hat values: {hat_values}, Linear: {msg.linear.x}, Angular.z: {msg.angular.z}, Angular.x: {msg.angular.x}, Button: {msg.linear.z}")

    def run_lidar_controller(self):
        # LIDAR 스캔 데이터를 기반으로 로봇을 제어하는 로직
        lidar = np.full((600, 600, 3), 255, np.uint8)
        cv2.arrowedLine(lidar, (lidar.shape[1] // 2, lidar.shape[0] // 2),
                        (lidar.shape[1] // 2, lidar.shape[0] // 2 - int(DISTANCE * 100)), (0, 255, 255), 2)

        # LIDAR 데이터가 없는 경우 실행하지 않음
        if not hasattr(self, 'latest_scan'):
            return

        scan = self.latest_scan  # 최신 LIDAR 데이터를 사용
        count = min(int(scan.scan_time / scan.time_increment), len(scan.ranges))  # scan.ranges의 길이로 제한
        flag_R, flag_L = False, False
        distance_R, angle_R, distance_L, angle_L = [], [], [], []
        distance_pts_R, distance_pts_L = [], []

        for i in range(count):
            degree = RAD2DEG(scan.angle_min + scan.angle_increment * i)
            lidar_range = scan.ranges[i]
            range_x = lidar.shape[1] // 2 - int((lidar_range / 3) * math.cos(degree * math.pi / 180.0) * (lidar.shape[1] // 2))
            range_y = lidar.shape[0] // 2 - int((lidar_range / 3) * math.sin(degree * math.pi / 180.0) * (lidar.shape[0] // 2))

            if -30 <= degree <= 30:
                if MINDISTANCE <= lidar_range < DISTANCE:
                    if degree < 0:
                        distance_R.append(lidar_range)
                        distance_pts_R.append((range_y, range_x))
                        angle_R.append(degree)
                        flag_R = True
                    else:
                        distance_L.append(lidar_range)
                        distance_pts_L.append((range_y, range_x))
                        angle_L.append(degree)
                        flag_L = True
                    cv2.circle(lidar, (range_y, range_x), 1, (0, 0, 255), -1)
                else:
                    cv2.circle(lidar, (range_y, range_x), 1, (0, 0, 255), -1)
            else:
                cv2.circle(lidar, (range_y, range_x), 1, (255, 0, 0), -1)

        self.min_distance_L = min(distance_L) if distance_L else float('inf')
        self.min_distance_R = min(distance_R) if distance_R else float('inf')

        if flag_L and flag_R:
            min_index_L = distance_L.index(self.min_distance_L)
            min_index_R = distance_R.index(self.min_distance_R)
            cv2.arrowedLine(lidar, (lidar.shape[1] // 2, lidar.shape[0] // 2), distance_pts_L[min_index_L], (0, 255, 0), 2)
            cv2.arrowedLine(lidar, (lidar.shape[1] // 2, lidar.shape[0] // 2), distance_pts_R[min_index_R], (255, 0, 0), 2)
            angle = angle_R[min_index_R] + angle_L[min_index_L]
            if angle != 0:
                self.error = ((DISTANCE * 100 - distance_pts_L[min_index_L][0]) -
                              (distance_pts_R[min_index_R][0] - (DISTANCE * 100 + lidar.shape[1] // 2))) / 2
            else:
                self.error = ((lidar.shape[1] // 2 + DISTANCE * 100) - distance_pts_R[min_index_R][0] -
                              (distance_pts_L[min_index_L][0] - (lidar.shape[1] // 2 - DISTANCE * 100))) / 2
        elif flag_R and not flag_L:
            min_index_R = distance_R.index(self.min_distance_R)
            cv2.arrowedLine(lidar, (lidar.shape[1] // 2, lidar.shape[0] // 2), distance_pts_R[min_index_R], (255, 0, 0), 2)
            self.error = (lidar.shape[1] // 2 + DISTANCE * 100) - distance_pts_R[min_index_R][0]
        elif not flag_R and flag_L:
            min_index_L = distance_L.index(self.min_distance_L)
            cv2.arrowedLine(lidar, (lidar.shape[1] // 2, lidar.shape[0] // 2), distance_pts_L[min_index_L], (0, 255, 0), 2)
            self.error = -(distance_pts_L[min_index_L][0] - (lidar.shape[1] // 2 - DISTANCE * 100))
        else:
            cv2.arrowedLine(lidar, (lidar.shape[1] // 2, lidar.shape[0] // 2),
                            (lidar.shape[1] // 2 + int(DISTANCE * 100), lidar.shape[0] // 2), (255, 0, 0), 2)
            cv2.arrowedLine(lidar, (lidar.shape[1] // 2, lidar.shape[0] // 2),
                            (lidar.shape[1] // 2 - int(DISTANCE * 100), lidar.shape[0] // 2), (255, 0, 0), 2)
            self.error = 0.0

        if self.error > 0:
            self.get_logger().info(f'현재 좌회전중 error: {self.error / 2.0}')
        elif self.error < 0:
            self.get_logger().info(f'현재 우회전중 error: {self.error / 2.0}')
        else:
            self.get_logger().info(f'현재 직진중 error: {self.error / 2.0}')

        cv2.imshow("lidar", lidar)
        cv2.waitKey(10)

        self.publish_velcmd_msg()

    def publish_velcmd_msg(self):
        msg = Twist()

        if self.min_distance_R < ZERODISTANCE or self.min_distance_L < ZERODISTANCE:
            msg.linear.x = 0.0
        else:
            msg.linear.x = 60.0

        msg.angular.z = self.error / 2.0
        self.publisher_.publish(msg)
        self.get_logger().info(f'cmd_vel 메시지 발행: linear.x = {msg.linear.x}, angular.z = {msg.angular.z}')

    def scan_callback(self, scan):
        # 최신 LIDAR 데이터를 저장하여, 필요할 때 사용
        self.latest_scan = scan


def main(args=None):
    rclpy.init(args=args)
    node = PadController()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
