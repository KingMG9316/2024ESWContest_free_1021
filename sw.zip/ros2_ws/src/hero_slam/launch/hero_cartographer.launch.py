from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='cartographer_ros',
            executable='cartographer_node',
            name='cartographer_node',
            output='screen',
            parameters=[{
                'use_sim_time': False,
            }],
            arguments=[
                '-configuration_directory', '/home/nvidia/ros2_ws/src/hero_slam/config',
                '-configuration_basename', 'hero_lidar.lua'
            ]
        ),
        Node(
            package='cartographer_ros',
            executable='occupancy_grid_node',
            name='occupancy_grid_node',
            output='screen',
            parameters=[{
                'resolution': 0.05,
                'publish_period_sec': 1.0,
            }],
        ),
        Node(
            package='imu_publisher_pkg',  # IMU 노드를 포함한 패키지 이름
            executable='imu_publisher',
            name='imu_node',
            output='screen',
            parameters=[{
                'port': '/dev/ttyUSB1',
                'baudrate': 115200
            }],
        ),
    ])
