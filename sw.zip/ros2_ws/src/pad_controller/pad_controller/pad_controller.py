import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import pygame

class PadController(Node):
    def __init__(self):
        super().__init__('pad_controller')
        self.publisher_ = self.create_publisher(Twist, 'cmd_vel', 10)
        self.timer = self.create_timer(0.1, self.timer_callback)

        pygame.init()
        pygame.joystick.init()

        joystick_count = pygame.joystick.get_count()
        self.get_logger().info(f"Number of joysticks: {joystick_count}")

        # Xbox One S Controller 찾기 및 초기화
        self.joystick = None
        for i in range(joystick_count):
            js = pygame.joystick.Joystick(i)
            js.init()
            self.get_logger().info(f"Joystick {i} name: {js.get_name()}")
            if 'Xbox One S Controller' in js.get_name():
                self.joystick = js
                self.get_logger().info(f"Selected joystick: {js.get_name()} at index {i}")
                break

        if self.joystick is None:
            self.get_logger().error("Xbox One S Controller not found")
            exit()

        self.get_logger().info(f"Using joystick: {self.joystick.get_name()}")
        self.get_logger().info(f"Number of axes: {self.joystick.get_numaxes()}")
        self.get_logger().info(f"Number of buttons: {self.joystick.get_numbuttons()}")
        self.get_logger().info(f"Number of hats: {self.joystick.get_numhats()}")

    def timer_callback(self):
        pygame.event.pump()

        # 축 값 읽기
        axis_values = [self.joystick.get_axis(i) for i in range(self.joystick.get_numaxes())]
        # 축 값이 -0.11에서 0.11 사이일 때 0으로 설정
        axis_values = [0.0 if -0.11 <= value <= 0.11 else value for value in axis_values]

        # 버튼 값 읽기
        button_values = [self.joystick.get_button(i) for i in range(self.joystick.get_numbuttons())]

        # Hat 값 읽기
        hat_values = [self.joystick.get_hat(i) for i in range(self.joystick.get_numhats())]

        # Twist 메시지 작성 및 발행
        msg = Twist()

        # 축 4와 축 5에 따른 msg.linear.x 설정
        if axis_values[4] > 0.9:
            msg.linear.x = 1.0
        elif -0.9 < axis_values[4] <= 0.9:
            msg.linear.x = 0.5
        elif -0.9 < axis_values[5] <= 0.9:
            msg.linear.x = -0.5
        elif axis_values[5] >= 0.9:
            msg.linear.x = -1.0
        else:
            msg.linear.x = 0.0

        # 축 0을 msg.angular.z로 설정
        msg.angular.z = float(axis_values[0])

        # Hat 값에 따른 msg.angular.x 설정
        if hat_values[0] == (0, 0):
            msg.angular.x = 0.0
        elif hat_values[0] == (1, 0):
            msg.angular.x = 1.0
        elif hat_values[0] == (-1, 0):
            msg.angular.x = -1.0
        elif hat_values[0] == (0, 1):
            msg.angular.x = 2.0
        elif hat_values[0] == (0, -1):
            msg.angular.x = -2.0
        elif hat_values[0] == (1, 1):
            msg.angular.x = 3.0
        elif hat_values[0] == (-1, -1):
            msg.angular.x = -3.0

        # 버튼에 따른 msg.linear.z 설정
        msg.linear.z = 0.0
        for i, pressed in enumerate(button_values):
            if pressed:
                msg.linear.z = float(i + 1)
                break

        self.publisher_.publish(msg)

        # 패드의 상태를 한 줄로 출력
        self.get_logger().info(f"Axis values: {axis_values}, Button values: {button_values}, Hat values: {hat_values}, Linear: {msg.linear.x}, Angular.z: {msg.angular.z}, Angular.x: {msg.angular.x}, Button: {msg.linear.z}")

def main(args=None):
    rclpy.init(args=args)
    node = PadController()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
