/*#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/int32.hpp>
#include <opencv2/opencv.hpp>
#include <iostream>
#include <algorithm>

int a = 0;

class LineDetectorNode : public rclcpp::Node {
public:
    LineDetectorNode() : Node("line_detector_node") {
        publisher_ = this->create_publisher<std_msgs::msg::Int32>("lowest_line_height", 10);
        timer_ = this->create_wall_timer(
            std::chrono::milliseconds(30),
            std::bind(&LineDetectorNode::processFrame, this));
        cap_.open(0);
    }

private:
    void processFrame() {
        if (!cap_.isOpened()) {
            RCLCPP_ERROR(this->get_logger(), "카메라를 열 수 없습니다.");
            return;
        }

        cv::Mat frame, gray, edge;
        cap_ >> frame;
        if (frame.empty()) return;

        cv::cvtColor(frame, gray, cv::COLOR_BGR2GRAY);
        cv::blur(gray, gray, cv::Size(3,3));
        cv::Canny(gray, edge, 50, 150, 3);

        std::vector<cv::Vec4i> lines;
        cv::HoughLinesP(edge, lines, 1, CV_PI/180, 50, 50, 10);

        double minAngle = -10.0 * (CV_PI / 180.0);
        double maxAngle = 10.0 * (CV_PI / 180.0);

        int lowestLineY = 0;

        for (size_t i = 0; i < lines.size(); i++) {
            cv::Vec4i l = lines[i];
            double angle = atan2(l[3] - l[1], l[2] - l[0]);

            if (angle > minAngle && angle < maxAngle) {
                cv::line(frame, cv::Point(l[0], l[1]), cv::Point(l[2], l[3]), cv::Scalar(0,0,255), 3, cv::LINE_AA);
                lowestLineY = std::max(lowestLineY, std::max(l[1], l[3]));
            }
        }

        if (lowestLineY > 0) {
            RCLCPP_INFO(this->get_logger(), "가장 낮은 가로선의 높이: %d", lowestLineY);
            std_msgs::msg::Int32 msg;
            //msg.data = lowestLineY;
            //if ((718 < lowestLineY) && (lowestLineY < 722)) a++;
            if (500 < lowestLineY) a++;
            if (a > 0) msg.data = 0;
            else msg.data = 1;
            RCLCPP_INFO(this->get_logger(), "메세지 값: %d a 값 %d", msg.data, a);
            publisher_->publish(msg);
        }

        cv::imshow("Frame", frame);
        cv::waitKey(30);
    }

    rclcpp::Publisher<std_msgs::msg::Int32>::SharedPtr publisher_;
    rclcpp::TimerBase::SharedPtr timer_;
    cv::VideoCapture cap_;
};

int main(int argc, char **argv) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<LineDetectorNode>());
    rclcpp::shutdown();
    return 0;
}*/
/*#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/int32.hpp>
#include <opencv2/opencv.hpp>
#include <iostream>
#include <algorithm>

int a = 0;

class LineDetectorNode : public rclcpp::Node {
public:
    LineDetectorNode() : Node("line_detector_node") {
        publisher_ = this->create_publisher<std_msgs::msg::Int32>("lowest_line_height", 10);
        timer_ = this->create_wall_timer(
            std::chrono::milliseconds(30),
            std::bind(&LineDetectorNode::processFrame, this));
        cap_.open(0);
    }

private:
    void processFrame() {
        if (!cap_.isOpened()) {
            RCLCPP_ERROR(this->get_logger(), "카메라를 열 수 없습니다.");
            return;
        }

        cv::Mat frame, gray, edge;
        cap_ >> frame;
        if (frame.empty()) return;

        // 전처리
        cv::cvtColor(frame, gray, cv::COLOR_BGR2GRAY);
        cv::GaussianBlur(gray, gray, cv::Size(5, 5), 2, 2);  // Gaussian 블러를 적용하여 노이즈를 줄임
        cv::Canny(gray, edge, 50, 150, 3);

        std::vector<cv::Vec4i> lines;
        cv::HoughLinesP(edge, lines, 1, CV_PI/180, 50, 50, 10);

        double minAngle = -10.0 * (CV_PI / 180.0);
        double maxAngle = 10.0 * (CV_PI / 180.0);

        int lowestLineY = 0;

        for (size_t i = 0; i < lines.size(); i++) {
            cv::Vec4i l = lines[i];
            double angle = atan2(l[3] - l[1], l[2] - l[0]);

            // 각도 필터링
            if (angle > minAngle && angle < maxAngle) {
                int lineLength = std::hypot(l[2] - l[0], l[3] - l[1]);
                // 길이 필터링: 100픽셀 이상인 선만 고려
                if (lineLength > 100) {
                    cv::line(frame, cv::Point(l[0], l[1]), cv::Point(l[2], l[3]), cv::Scalar(0,0,255), 3, cv::LINE_AA);
                    lowestLineY = std::max(lowestLineY, std::max(l[1], l[3]));
                }
            }
        }

        if (lowestLineY > 0) {
            RCLCPP_INFO(this->get_logger(), "가장 낮은 가로선의 높이: %d", lowestLineY);
            std_msgs::msg::Int32 msg;
            if (700 < lowestLineY) a++;
            if (a > 0) msg.data = 0;
            else msg.data = 1;
            RCLCPP_INFO(this->get_logger(), "메세지 값: %d a 값 %d", msg.data, a);
            publisher_->publish(msg);
        }

        cv::imshow("Frame", frame);
        cv::waitKey(30);
    }

    rclcpp::Publisher<std_msgs::msg::Int32>::SharedPtr publisher_;
    rclcpp::TimerBase::SharedPtr timer_;
    cv::VideoCapture cap_;
};

int main(int argc, char **argv) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<LineDetectorNode>());
    rclcpp::shutdown();
    return 0;
}*/

#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/int32.hpp>
#include <opencv2/opencv.hpp>
#include <iostream>
#include <algorithm>
#include <vector>

int a = 0;

class LineDetectorNode : public rclcpp::Node {
public:
    LineDetectorNode() : Node("line_detector_node") {
        publisher_ = this->create_publisher<std_msgs::msg::Int32>("lowest_line_height", 10);
        timer_ = this->create_wall_timer(
            std::chrono::milliseconds(30),
            std::bind(&LineDetectorNode::processFrame, this));
        cap_.open(0);
    }

private:
    void processFrame() {
        if (!cap_.isOpened()) {
            RCLCPP_ERROR(this->get_logger(), "카메라를 열 수 없습니다.");
            return;
        }

        cv::Mat frame, gray, edge;
        cap_ >> frame;
        if (frame.empty()) return;

        // 전처리
        cv::cvtColor(frame, gray, cv::COLOR_BGR2GRAY);
        cv::GaussianBlur(gray, gray, cv::Size(5, 5), 2, 2);  // Gaussian 블러를 적용하여 노이즈를 줄임
        cv::Canny(gray, edge, 50, 150, 3);

        std::vector<cv::Vec4i> lines;
        //cv::HoughLinesP(edge, lines, 1, CV_PI/180, 50, 50, 10);
        cv::HoughLinesP(edge, lines, 1, CV_PI/180, 200, 800, 1280);

        //double minAngle = -10.0 * (CV_PI / 180.0);
        //double maxAngle = 10.0 * (CV_PI / 180.0);
        double minAngle = -1.0 * (CV_PI / 180.0);
        double maxAngle = 1.0 * (CV_PI / 180.0);

        int lowestLineY = 0;
        std::vector<cv::Vec4i> horizontalLines;

        for (size_t i = 0; i < lines.size(); i++) {
            cv::Vec4i l = lines[i];
            double angle = atan2(l[3] - l[1], l[2] - l[0]);

            // 각도 필터링
            if (angle > minAngle && angle < maxAngle) {
                int lineLength = std::hypot(l[2] - l[0], l[3] - l[1]);
                // 길이 필터링: 100픽셀 이상인 선만 고려
                if (lineLength > 100) {
                    horizontalLines.push_back(l);
                    lowestLineY = std::max(lowestLineY, std::max(l[1], l[3]));
                }
            }
        }

        // 비슷한 높이의 선을 그룹화하고 이음
        std::vector<cv::Vec4i> mergedLines;
        const int heightThreshold = 10; // y좌표 차이가 이 값 이내이면 하나의 선으로 합침

        for (size_t i = 0; i < horizontalLines.size(); ++i) {
            cv::Vec4i l1 = horizontalLines[i];
            bool merged = false;

            for (size_t j = 0; j < mergedLines.size(); ++j) {
                cv::Vec4i& l2 = mergedLines[j];

                if ((std::abs(l1[1] - l2[1]) < heightThreshold && std::abs(l1[3] - l2[3]) < heightThreshold) ||
                    (std::abs(l1[1] - l2[3]) < heightThreshold && std::abs(l1[3] - l2[1]) < heightThreshold)) {
                    // l1과 l2를 하나의 선으로 합침
                    l2[0] = std::min(l2[0], l1[0]);
                    l2[1] = (l2[1] + l1[1]) / 2; // y좌표를 평균값으로 설정
                    l2[2] = std::max(l2[2], l1[2]);
                    l2[3] = (l2[3] + l1[3]) / 2; // y좌표를 평균값으로 설정
                    merged = true;
                    break;
                }
            }

            if (!merged) {
                mergedLines.push_back(l1);
            }
        }

        for (size_t i = 0; i < mergedLines.size(); ++i) {
            cv::Vec4i l = mergedLines[i];
            cv::line(frame, cv::Point(l[0], l[1]), cv::Point(l[2], l[3]), cv::Scalar(0, 0, 255), 3, cv::LINE_AA);
        }

        if (lowestLineY > 0) {
            RCLCPP_INFO(this->get_logger(), "가장 낮은 가로선의 높이: %d", lowestLineY);
            std_msgs::msg::Int32 msg;
            if (500 < lowestLineY) a++;
            if (a > 0) msg.data = 0;
            else msg.data = 1;
            RCLCPP_INFO(this->get_logger(), "메세지 값: %d a 값 %d", msg.data, a);
            publisher_->publish(msg);
        }

        cv::imshow("Frame", frame);
        cv::waitKey(30);
    }

    rclcpp::Publisher<std_msgs::msg::Int32>::SharedPtr publisher_;
    rclcpp::TimerBase::SharedPtr timer_;
    cv::VideoCapture cap_;
};

int main(int argc, char **argv) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<LineDetectorNode>());
    rclcpp::shutdown();
    return 0;
}
