import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Imu
import serial
import struct

class ImuPublisher(Node):
    def __init__(self):
        super().__init__('imu_publisher')
        self.publisher_ = self.create_publisher(Imu, 'imu', 10)
        self.timer = self.create_timer(0.1, self.timer_callback)
        self.serial_port = serial.Serial('/dev/ttyUSB1', 115200, timeout=1)

    def timer_callback(self):
        if self.serial_port.in_waiting > 0:
            data = self.serial_port.read(36)  # Adjust based on IMU data packet size
            imu_msg = Imu()
            # Parse the data and fill imu_msg with appropriate values
            # Example: imu_msg.orientation.x = struct.unpack('f', data[0:4])[0]
            self.publisher_.publish(imu_msg)

def main(args=None):
    rclpy.init(args=args)
    node = ImuPublisher()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
