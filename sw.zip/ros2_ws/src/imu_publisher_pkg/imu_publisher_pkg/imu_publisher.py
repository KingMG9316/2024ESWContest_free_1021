import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Imu
import serial
import math

class ImuPublisher(Node):
    def __init__(self):
        super().__init__('imu_publisher')

        # 포트와 보드레이트를 파라미터로 받아옵니다.
        self.declare_parameter('port', '/dev/ttyUSB1')
        self.declare_parameter('baudrate', 115200)

        port = self.get_parameter('port').get_parameter_value().string_value
        baudrate = self.get_parameter('baudrate').get_parameter_value().integer_value

        # 시리얼 포트를 설정합니다.
        try:
            self.serial_port = serial.Serial(port, baudrate, timeout=1)
            self.get_logger().info(f"Opened serial port: {port} with baudrate: {baudrate}")
        except serial.SerialException as e:
            self.get_logger().error(f"Failed to open serial port: {e}")
            rclpy.shutdown()

        self.publisher_ = self.create_publisher(Imu, 'imu', 10)
        self.timer = self.create_timer(0.01, self.timer_callback)  # 20Hz로 데이터를 퍼블리시

    def timer_callback(self):
        if self.serial_port.in_waiting > 0:
            line = self.serial_port.readline().decode('utf-8').strip()  # 한 줄을 읽어서 디코딩
            self.get_logger().info(f"Raw line: {line}")  # 원시 데이터 출력

            # '*'를 제거하고 데이터를 파싱
            line = line.lstrip('*')
            
            try:
                # 데이터를 쉼표로 분리하여 파싱
                values = list(map(float, line.split(',')))
                if len(values) == 12:  # 센서 데이터의 모든 값이 수신되었는지 확인
                    imu_msg = Imu()
                    imu_msg.header.stamp = self.get_clock().now().to_msg()
                    imu_msg.header.frame_id = "base_link"

                    # 가속도 데이터 설정 (g -> m/s²)
                    imu_msg.linear_acceleration.x = values[6] * 9.80665
                    imu_msg.linear_acceleration.y = values[7] * 9.80665
                    imu_msg.linear_acceleration.z = values[8] * 9.80665

                    # 자이로스코프 데이터 설정 (deg/s -> rad/s)
                    imu_msg.angular_velocity.x = values[3] * (math.pi / 180)
                    imu_msg.angular_velocity.y = values[4] * (math.pi / 180)
                    imu_msg.angular_velocity.z = values[5] * (math.pi / 180)

                    # Orientation은 기본 값으로 설정
                    imu_msg.orientation.x = 0.0
                    imu_msg.orientation.y = 0.0
                    imu_msg.orientation.z = 0.0
                    imu_msg.orientation.w = 1.0

                    self.publisher_.publish(imu_msg)
                    self.get_logger().info(f"Published IMU data: {imu_msg}")
            except ValueError as e:
                self.get_logger().error(f"Error parsing line: {line}, error: {e}")
    

def main(args=None):
    rclpy.init(args=args)
    node = ImuPublisher()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
