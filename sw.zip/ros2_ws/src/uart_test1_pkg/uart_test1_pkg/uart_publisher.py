import rclpy
from rclpy.node import Node
from std_msgs.msg import Int32
import serial
import struct

class Int32Publisher(Node):
    def __init__(self):
        super().__init__('int32_publisher')
        self.publisher_ = self.create_publisher(Int32, 'mcu', 10)
        timer_period = 0.5  # seconds
        self.timer = self.create_timer(timer_period, self.timer_callback)
        self.i = 0
        self.ser = serial.Serial('/dev/ttyUSB0', 115200)  # 시리얼 포트 설정

    def timer_callback(self):
        msg = Int32()
        msg.data = self.i
        self.publisher_.publish(msg)
        self.get_logger().info('Publishing: "%d"' % msg.data)

        # int32 형식으로 데이터를 STM32에 전송
        self.ser.write(struct.pack('<i', msg.data))

        self.i += 1

    def __del__(self):
        self.ser.close()  # 노드가 종료될 때 시리얼 포트를 닫습니다.

def main(args=None):
    rclpy.init(args=args)
    int32_publisher = Int32Publisher()
    rclpy.spin(int32_publisher)
    int32_publisher.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
