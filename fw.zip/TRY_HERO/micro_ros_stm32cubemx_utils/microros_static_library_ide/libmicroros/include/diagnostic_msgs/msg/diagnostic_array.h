// generated from rosidl_generator_c/resource/idl.h.em
// with input from diagnostic_msgs:msg/DiagnosticArray.idl
// generated code does not contain a copyright notice

#ifndef DIAGNOSTIC_MSGS__MSG__DIAGNOSTIC_ARRAY_H_
#define DIAGNOSTIC_MSGS__MSG__DIAGNOSTIC_ARRAY_H_

#include "diagnostic_msgs/msg/detail/diagnostic_array__struct.h"
#include "diagnostic_msgs/msg/detail/diagnostic_array__functions.h"
#include "diagnostic_msgs/msg/detail/diagnostic_array__type_support.h"

#endif  // DIAGNOSTIC_MSGS__MSG__DIAGNOSTIC_ARRAY_H_
