/*
 * usimu.c
 *
 *  Created on: Apr 20, 2024
 *      Author: seon
 */
#include "usimu.h"
#include "usart.h"
#include "tim.h"
#include "math.h"
#include "qfmathex.h"
#include "qffmath.h"

// Balance control parameter
#define PI                (3.14159265358979323846)
#define Rad2Deg           ((180) / (3.14159265358979323846))
#define Deg2Rad           ((3.14159265358979323846) / (180))

#define LEG_LENGTH 5.0
#define WHEEL_RADIUS 10.0
#define BODY_WIDTH 30.0  // 로봇 몸체의 폭 (좌우 거리)
#define BODY_LENGTH 40.0 // 로봇 몸체의 길이 (전후 거리)

// LED control parameter
#define NUM_LEDS 5
#define LED_DATA_SIZE (NUM_LEDS * 24)
#define RESET_SLOTS 50

static char sbuf[64];
static uint16_t sbuf_cnt = 0;

uint8_t LED_Data[NUM_LEDS][3];
uint16_t pwmData[LED_DATA_SIZE + RESET_SLOTS];

void PID_Init(PID *pid, double Kp, double Ki, double Kd) {
	pid->Kp = Kp;
	pid->Ki = Ki;
	pid->Kd = Kd;
	pid->prev_error = 0;
	pid->integral = 0;
}

float PID_Compute(PID *pid, float setpoint, float measurement) {
    float time = 0.1;
    float error = setpoint - measurement;

    if (qFMathEx_AlmostEqual(error, 0.0, 0.05)) {
    	return 0.0;
    }

    pid->integral += error * time;
    float derivative = (error - pid->prev_error) / time;
    pid->prev_error = error;

    return (pid->Kp * error) + (pid->Ki * pid->integral) + (pid->Kd * derivative);
}

// Fuzzy PID Gain Auto tuning in progress

/*float PID_Compute(PID *pid, float setpoint, float measurement) {
	float error = setpoint - measurement;

	if (qFMathEx_AlmostEqual(error, 0.0, 0.05)) {
		return 0.0;
	}

	float derivative;
	float e_scaled = error; // Scaling
	float ec_scaled = (error - pid->prev_error); // Scaling

	float es[7], ecs[7], form[7][7];
	int i, j, MaxX = 0, MaxY = 0;
	float lsd, detkp, detkd, detki;
	int temp_p, temp_d, temp_i;

	// 퍼지화
	es[NB] = FTraL(e_scaled, -20, -12);
	es[NM] = FTri(e_scaled, -16, -12, -8);
	es[NS] = FTri(e_scaled, -10, -6, -2);
	es[ZO] = FTri(e_scaled, -4, 0, 4);
	es[PS] = FTri(e_scaled, 2, 6, 10);
	es[PM] = FTri(e_scaled, 8, 12, 16);
	es[PB] = FTraR(e_scaled, 12, 20);

	//FIX ECS it's wrong!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	ecs[NB] = FTraL(ec_scaled, -20, -12);
	ecs[NM] = FTri(ec_scaled, -16, -12, -8);
	ecs[NS] = FTri(ec_scaled, -10, -6, -2);
	ecs[ZO] = FTri(ec_scaled, -4, 0, 4);
	ecs[PS] = FTri(ec_scaled, 2, 6, 10);
	ecs[PM] = FTri(ec_scaled, 8, 12, 16);
	ecs[PB] = FTraR(ec_scaled, 12, 20);

	// 퍼지 추론
	for (i = 0; i < 7; i++) {
		for (j = 0; j < 7; j++) {
			form[i][j] = qFFMath_Min(es[i], ecs[j]);
		}
	}

	for (i = 0; i < 7; i++) {
		for (j = 0; j < 7; j++) {
			if (form[MaxX][MaxY] < form[i][j]) {
				MaxX = i;
				MaxY = j;
			}
		}
	}

	lsd = form[MaxX][MaxY];
	temp_p = kp[MaxX][MaxY];
	temp_d = kd[MaxX][MaxY];
	temp_i = ki[MaxX][MaxY];

	// 탈퍼지화 및 PID 파라미터 조정
	if (temp_p == NB)
		detkp = uFTraL(lsd, -0.3, -0.1);
	else if (temp_p == NM)
		detkp = uFTri(lsd, -0.3, -0.2, 0);
	else if (temp_p == NS)
		detkp = uFTri(lsd, -0.3, -0.1, 0.1);
	else if (temp_p == ZO)
		detkp = uFTri(lsd, -0.2, 0, 0.2);
	else if (temp_p == PS)
		detkp = uFTri(lsd, -0.1, 0.1, 0.3);
	else if (temp_p == PM)
		detkp = uFTri(lsd, 0, 0.2, 0.3);
	else if (temp_p == PB)
		detkp = uFTraR(lsd, 0.1, 0.3);

	if (temp_d == NB)
		detkd = uFTraL(lsd, -0.03, -0.01);
	else if (temp_d == NM)
		detkd = uFTri(lsd, -0.03, -0.02, 0);
	else if (temp_d == NS)
		detkd = uFTri(lsd, -0.03, 0.01, 0.01);
	else if (temp_d == ZO)
		detkd = uFTri(lsd, -0.02, 0, 0.02);
	else if (temp_d == PS)
		detkd = uFTri(lsd, -0.01, 0.01, 0.03);
	else if (temp_d == PM)
		detkd = uFTri(lsd, 0, 0.02, 0.03);
	else if (temp_d == PB)
		detkd = uFTraR(lsd, 0.01, 0.03);

	if (temp_i == NB)
		detki = uFTraL(lsd, -0.6, -0.2);
	else if (temp_i == NM)
		detki = uFTri(lsd, -0.6, -0.4, 0);
	else if (temp_i == NS)
		detki = uFTri(lsd, -0.6, -0.2, 0.2);
	else if (temp_i == ZO)
		detki = uFTri(lsd, -0.4, 0, 0.4);
	else if (temp_i == PS)
		detki = uFTri(lsd, -0.2, 0.2, 0.6);
	else if (temp_i == PM)
		detki = uFTri(lsd, 0, 0.4, 0.6);
	else if (temp_i == PB)
		detki = uFTraR(lsd, 0.2, 0.6);

	// PID 파라미터 조정
	pid->Kp += detkp;
	if (pid->Kp < 0) pid->Kp = 0;

	pid->Ki += detki;
	if (pid->Ki < 0) pid->Ki = 0;

	pid->Kd += detkd;
	if (pid->Kd < 0) pid->Kd = 0;

	// PID 계산
	pid->integral += error * pid->time;
	derivative = (error - pid->prev_error) / pid->time;
	pid->prev_error = error;



	return (pid->Kp * error) + (pid->Ki * pid->integral) + (pid->Kd * derivative);
}*/


int EBimuAsciiParser(float *item, uint16_t number_of_item)
{
	char *addr;
	int result = 0;

	if(uartAvailable('6') > 0)
	{
		sbuf[sbuf_cnt] = uartRead('6');
		if(sbuf[sbuf_cnt] == 0x0a)
		{
			addr = strtok(sbuf,",");
			for(uint16_t i = 0; i<number_of_item;i++)
			{
				item[i] = atof(addr);
				addr = strtok(NULL,",");
			}

			result = 1;
		}
		else if(sbuf[sbuf_cnt]=='*')
		{
			sbuf_cnt=-1;
		}

		sbuf_cnt++;
		if(sbuf_cnt>=64) sbuf_cnt=0;
	}
	return result;
}

float calculate_leg_angle(float desired_height) {
	float min_height = WHEEL_RADIUS - LEG_LENGTH;
	float max_height = WHEEL_RADIUS + LEG_LENGTH;

	if (desired_height < min_height) {
		desired_height = min_height;
	} else if (desired_height > max_height) {
		desired_height = max_height;
	}

	float angle = qFFMath_ACos((desired_height - WHEEL_RADIUS) / LEG_LENGTH);
	float angle_deg = angle * Rad2Deg;

	if (qFFMath_Abs(angle_deg) < 0.2f) {
		angle_deg = 0.0f;
	}

	return angle_deg;
}

void calculate_leg_positions(float *euler,
		                     PID *rollPID,
							 PID *pitchPID,
							 float base_height,
							 float leg_positions[4][3]) {

    float roll_orig = 1.23;
    float pitch_orig = -0.61;

    float pitch_control = PID_Compute(pitchPID, pitch_orig, euler[1]) * Deg2Rad;
    float roll_control = PID_Compute(rollPID, roll_orig, euler[0]) * Deg2Rad;

    float legs[4][3] = {
        { BODY_LENGTH / 2,  BODY_WIDTH / 2, 0 },  //front left
        { BODY_LENGTH / 2, -BODY_WIDTH / 2, 0 },  //front right
        {-BODY_LENGTH / 2,  BODY_WIDTH / 2, 0 },  //back left
        {-BODY_LENGTH / 2, -BODY_WIDTH / 2, 0 }   //back right
    };

    float R_roll[3][3] = {
        {1, 0, 0},
        {0, qFFMath_Cos(roll_control), qFFMath_Sin(roll_control)},
        {0, -qFFMath_Sin(roll_control), qFFMath_Cos(roll_control)}
    };

    float R_pitch[3][3] = {
        {qFFMath_Cos(pitch_control), 0, qFFMath_Sin(pitch_control)},
        {0, 1, 0},
        {-qFFMath_Sin(pitch_control), 0, qFFMath_Cos(pitch_control)}
    };

    for (int i = 0; i < 4; i++) {
        float y = legs[i][1];
        float z = legs[i][2];

        float temp_y = R_roll[1][1] * y + R_roll[1][2] * z;
        float temp_z = R_roll[2][1] * y + R_roll[2][2] * z;

        legs[i][1] = temp_y;
        legs[i][2] = temp_z;
    }

    for (int i = 0; i < 4; i++) {
        float x = legs[i][0];
        float z = legs[i][2];

        float temp_x = R_pitch[0][0] * x + R_pitch[0][2] * z;
        float temp_z = R_pitch[2][0] * x + R_pitch[2][2] * z;

        leg_positions[i][0] = temp_x;
        leg_positions[i][1] = legs[i][1];
        leg_positions[i][2] = temp_z + base_height;
    }
}

void delay (uint16_t time)
{
	__HAL_TIM_SET_COUNTER(&htim3, 0);
	while (__HAL_TIM_GET_COUNTER (&htim3) < time);
}

void US_Read(void)
{
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_SET);
	delay(10);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET);

	__HAL_TIM_ENABLE_IT(&htim3, TIM_IT_CC1);
	HAL_Delay(100);
}


void setLED(int LEDnum, uint8_t red, uint8_t green, uint8_t blue) {
    LED_Data[LEDnum][0] = green;
    LED_Data[LEDnum][1] = red;
    LED_Data[LEDnum][2] = blue;
}

void setColor(int LEDnum, uint8_t num) {
    switch(num) {
    case 'r': // Red color
        setLED(LEDnum, 0xFF, 0x00, 0x00);
        break;
    case 'g': // Green color
        setLED(LEDnum, 0x00, 0xFF, 0x00);
        break;
    case 'b': // Blue color
        setLED(LEDnum, 0x00, 0x00, 0xFF);
        break;
    case 'y': // Yellow color
        setLED(LEDnum, 0xFF, 0xFF, 0x00);
        break;
    case 'c': // Cyan color
    	setLED(LEDnum, 0x00, 0xFF, 0xFF);
    	break;
    case 'm': // Magenta color
    	setLED(LEDnum, 0xFF, 0x00, 0xFF);
    	break;
    case 'o': // Orange color
    	setLED(LEDnum, 0xFF, 0x59, 0x00); // Red 100%, Green 50%, Blue 0%
    	break;
    case 'q': // Magenta color
    	setLED(LEDnum, 0x00, 0x00, 0x00);
    	break;
    default: // White color
        setLED(LEDnum, 0xFF, 0xFF, 0xFF);
        break;
    }
}

void updateLEDs(uint32_t channel) {
    uint32_t indx = 0;
    for (int i = 0; i < NUM_LEDS; i++) {
        for (int j = 7; j >= 0; j--) {
            pwmData[indx++] = (LED_Data[i][0] & (1 << j)) ? 180 : 60; // Green
        }
        for (int j = 7; j >= 0; j--) {
            pwmData[indx++] = (LED_Data[i][1] & (1 << j)) ? 180 : 60; // Red
        }
        for (int j = 7; j >= 0; j--) {
            pwmData[indx++] = (LED_Data[i][2] & (1 << j)) ? 180 : 60; // Blue
        }
    }

    for (int i = 0; i < 50; i++) {
        pwmData[indx++] = 0;
    }

    HAL_TIM_PWM_Start_DMA(&htim1, channel, (uint32_t*)pwmData, indx);
    HAL_Delay(1);
}



void blinkcolor(uint8_t cl, uint32_t channel, uint8_t direction, uint32_t* last_time) {
	uint32_t current_time = HAL_GetTick();

	if (current_time - *last_time >= 1000) {
		if (direction == 0) {
			for (int i = 0; i < NUM_LEDS; i += 2) {
				setColor(i, cl);
				if (i + 1 < NUM_LEDS) {
					setColor(i + 1, cl);
				}
				updateLEDs(channel);
				HAL_Delay(20);
				setColor(i, 'q');
				if (i + 1 < NUM_LEDS) {
					setColor(i + 1, 'q');
				}
				updateLEDs(channel);
			}
		} else {
			for (int i = NUM_LEDS - 1; i >= 0; i -= 2) {
				setColor(i, cl);
				if (i - 1 >= 0) {
					setColor(i - 1, cl);
				}
				updateLEDs(channel);
				HAL_Delay(20);
				setColor(i, 'q');
				if (i - 1 >= 0) {
					setColor(i - 1, 'q');
				}
				updateLEDs(channel);
			}
		}
		*last_time = current_time;
	}
}

void LEDround(uint8_t dir, uint8_t cl) {
    static uint32_t last_time1 = 0;
    static uint32_t last_time2 = 0;
    static uint32_t last_time3 = 0;
    static uint32_t last_time4 = 0;

    if (dir == 'l') {
        blinkcolor(cl, TIM_CHANNEL_1, 1, &last_time1);
        blinkcolor(cl, TIM_CHANNEL_3, 0, &last_time2);
        blinkcolor(cl, TIM_CHANNEL_4, 1, &last_time3);
        blinkcolor(cl, TIM_CHANNEL_2, 0, &last_time4);
    } else {
        blinkcolor(cl, TIM_CHANNEL_1, 0, &last_time1);
        blinkcolor(cl, TIM_CHANNEL_2, 1, &last_time2);
        blinkcolor(cl, TIM_CHANNEL_4, 0, &last_time3);
        blinkcolor(cl, TIM_CHANNEL_3, 1, &last_time4);
    }
}

void setInitialColors(void) {
    for (int i = 0; i < NUM_LEDS; i++) {
        setColor(i, 'q'); // White color
    }
    updateLEDs(TIM_CHANNEL_1);
    updateLEDs(TIM_CHANNEL_2);
    updateLEDs(TIM_CHANNEL_3);
    updateLEDs(TIM_CHANNEL_4);

}

void TurnLed(uint32_t channel, uint8_t cl) {
    for (int i = 0; i < NUM_LEDS; i++) {
        setColor(i, cl); // White color
    }
    updateLEDs(channel);
}

void turnOffLED(uint32_t channel, int LEDnum) {
    for (int i = 0; i < LEDnum; i++) {
    	setLED(i, 0, 0, 0);
    }
    updateLEDs(channel);
}












