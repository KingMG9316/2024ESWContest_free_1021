/*
 * servo.h
 *
 *  Created on: Jan 25, 2024
 *      Author: LG
 */
#include "servo.h"
#include "tim.h"

#define STEP_SIZE 8
#define NUM_MOTORS 4

#define ACCELERATION_TIME 1000 // 가속 시간 (ms)
#define DECELERATION_TIME 1000 // 감속 시간 (ms)
#define MAX_SPEED 30.0 // 최대 속도 설정 예시 (각도/초)

void servoInit(void)
{
	HAL_TIM_PWM_Start(&htim4,TIM_CHANNEL_1);
	HAL_TIM_PWM_Start(&htim4,TIM_CHANNEL_2);
	HAL_TIM_PWM_Start(&htim4,TIM_CHANNEL_3);
	HAL_TIM_PWM_Start(&htim4,TIM_CHANNEL_4);
/*
	TIM4->CCR1 = 800;
	TIM4->CCR2 = 2000;
	TIM4->CCR3 = 1300;
	TIM4->CCR4 = 1500;*/
	ServoOrigin();
}

uint32_t DegtoPWM(uint32_t deg)
{
	uint32_t numerator = (deg - 0) * (2500 - 500) + (180 - 0) / 2;
	uint32_t denominator = 180 - 0;

	return 500 + numerator / denominator;
}

void ServoOrigin(void)
{
	moveServo(86, 98, 90, 85);
}

void Turn(int16_t dir)
{
	//servo param : left = 1, 105 / 2, 135 / 3, 75 / 4, 45 / right = 1, 75 / 2, 45 / 3, 105 / 4, 135
	switch(dir)
	{
	//left
	case 1:
		moveServo(103, 100, 65, 68);
		break;
	case 2:
		moveServo(98, 120, 75, 70);
		break;
	case 3:
		moveServo(113, 130, 75, 55);
		break;
	//right
	case -1:
		moveServo(68, 65, 100, 92);
		break;
	case -2:
		moveServo(65, 88, 110, 98);
		break;
	case -3:
		moveServo(75, 70, 110, 104);
		break;
	}

}

void CrabWalk(uint8_t dir)
{
	//servo param = 1, 115 / 2, 115 / 3, 115 / 4, 115 / 1, 65 / 2, 65 / 3, 65 / 4, 65
	if(dir == 'l')
	{
		moveServo(115, 125, 115, 115);
	}
	else if (dir == 'r')
	{
		moveServo(65, 75, 65, 65);
	}

}

void ZeroTurn(void)
{
	moveServo(42, 138, 135, 45);
}

uint32_t targetPWMs[NUM_MOTORS] = {0};

void moveServo(uint32_t deg1, uint32_t deg2, uint32_t deg3, uint32_t deg4)
{
    uint32_t pre_time;
    uint32_t targetAngle[NUM_MOTORS] = {deg1, deg2, deg3, deg4};
    uint32_t denominator = 180 - 0;

    for (int i = 0; i < NUM_MOTORS; i++)
    {
    	uint32_t numerator = (targetAngle[i] - 0) * (2500 - 500) + (180 - 0) / 2;
    	targetPWMs[i] = 500 + numerator / denominator;


    }



    pre_time = millis();

    while (!areAllMotorsAtTarget())
    {
        if (millis() - pre_time >= 3)
        {
            pre_time = millis();

            if (TIM4->CCR1 < targetPWMs[0])
            {
            	TIM4->CCR1 += 1; // 각 모터에 대한 PWM 증가
            	if( TIM4->CCR1 > targetPWMs[0] ) TIM4->CCR1 = targetPWMs[0];
            }
            else if (TIM4->CCR1 > targetPWMs[0])
            {
            	TIM4->CCR1 -= 1; // 각 모터에 대한 PWM 감소
            	if( TIM4->CCR1 < targetPWMs[0] ) TIM4->CCR1 = targetPWMs[0];
            }
            else
            {
            	TIM4->CCR1 += 0;
            }

            if (TIM4->CCR2 < targetPWMs[1])
            {
            	TIM4->CCR2 += 1; // 각 모터에 대한 PWM 증가
            	if( TIM4->CCR2 > targetPWMs[1] ) TIM4->CCR2 = targetPWMs[1];
            }
            else if (TIM4->CCR2 > targetPWMs[1])
            {
            	TIM4->CCR2 -= 1; // 각 모터에 대한 PWM 감소
            	if( TIM4->CCR2 < targetPWMs[1] ) TIM4->CCR2 = targetPWMs[1];
            }
            else
            {
            	TIM4->CCR2 += 0;
            }

            if (TIM4->CCR3 < targetPWMs[2])
            {
            	TIM4->CCR3 += 1; // 각 모터에 대한 PWM 증가
            	if( TIM4->CCR3 > targetPWMs[2] ) TIM4->CCR3 = targetPWMs[2];
            }
            else if (TIM4->CCR3 > targetPWMs[2])
            {
            	TIM4->CCR3 -= 1; // 각 모터에 대한 PWM 감소
            	if( TIM4->CCR3 < targetPWMs[2] ) TIM4->CCR3 = targetPWMs[2];
            }

            else
            {
            	TIM4->CCR3 += 0;
            }
            if (TIM4->CCR4 < targetPWMs[3])
            {
            	TIM4->CCR4 += 1; // 각 모터에 대한 PWM 증가
            	if( TIM4->CCR4 > targetPWMs[3] ) TIM4->CCR4 = targetPWMs[3];
            }
            else if (TIM4->CCR4 > targetPWMs[3])
            {
            	TIM4->CCR4 -= 1; // 각 모터에 대한 PWM 감소
            	if( TIM4->CCR4 < targetPWMs[3] ) TIM4->CCR4 = targetPWMs[3];
            }
            else
            {
            	TIM4->CCR4 += 0;
            }

        }
    }
}


int areAllMotorsAtTarget(void)
{

	if (TIM4->CCR1 != targetPWMs[0] || TIM4->CCR2 != targetPWMs[1] ||
			TIM4->CCR3 != targetPWMs[2] || TIM4->CCR4 != targetPWMs[3])
	{
		return 0;
	}

	return 1;
}


