/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <rcl/rcl.h>
#include <rcl/error_handling.h>
#include <rclc/rclc.h>
#include <rclc/executor.h>
#include <uxr/client/transport.h>
#include <rmw_microxrcedds_c/config.h>
#include <rmw_microros/rmw_microros.h>


#include "sensor_msgs/msg/joy.h"
#include <std_msgs/msg/int32.h>
#include <geometry_msgs/msg/twist.h>

#include "dxl.h"
#include "servo.h"
#include "usimu.h"
#include "usart.h"
#include "tim.h"
#include "qffmath.h"
#include "qfmathex.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */

float euler[3];

PID rollPID, pitchPID;

uint32_t Distance  = 0;
uint32_t IC_Val1 = 0;
uint32_t IC_Val2 = 0;
uint32_t Difference = 0;
uint8_t Is_First_Captured = 0;  // is the first value captured ?

float base_height = 15.0f;

int32_t stpos = 0;
int32_t stpos2 = 0;


//int16_t cnt = 0;
int16_t prev_y = 0;

//micro-ROS parameter
geometry_msgs__msg__Twist tw_msg;
std_msgs__msg__Int32 msg;

rclc_support_t support;
rcl_allocator_t allocator;
rcl_node_t node;
rcl_publisher_t publisher;
rcl_publisher_t publisher2;
rcl_publisher_t publisher3;
rcl_subscription_t subscriber;
rcl_subscription_t subscriber2;
rcl_subscription_t subscriber3;
rclc_executor_t executor;

//subscription callback parameter
uint32_t last_time = 0;
static int32_t vel1 = 0;
static int32_t vel2 = 0;
static int32_t pos1 = 0;
static int32_t pos2 = 0;

/* USER CODE END Variables */
/* Definitions for defaultTask */
osThreadId_t defaultTaskHandle;
const osThreadAttr_t defaultTask_attributes = {
  .name = "defaultTask",
  .stack_size = 3000 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
/* Definitions for myTask02 */
osThreadId_t myTask02Handle;
const osThreadAttr_t myTask02_attributes = {
  .name = "myTask02",
  .stack_size = 512 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */
bool cubemx_transport_open(struct uxrCustomTransport * transport);
bool cubemx_transport_close(struct uxrCustomTransport * transport);
size_t cubemx_transport_write(struct uxrCustomTransport* transport, const uint8_t * buf, size_t len, uint8_t * err);
size_t cubemx_transport_read(struct uxrCustomTransport* transport, uint8_t* buf, size_t len, int timeout, uint8_t* err);

void * microros_allocate(size_t size, void * state);
void microros_deallocate(void * pointer, void * state);
void * microros_reallocate(void * pointer, size_t size, void * state);
void * microros_zero_allocate(size_t number_of_elements, size_t size_of_element, void * state);


void error_loop(){
}

#define RCCHECK(fn) { rcl_ret_t temp_rc = fn; if((temp_rc != RCL_RET_OK)){error_loop();}}
#define RCSOFTCHECK(fn) { rcl_ret_t temp_rc = fn; if((temp_rc != RCL_RET_OK)){error_loop();}}




void subscription_callback(const void * msgin)
{
	uint32_t current_time = millis();
	const geometry_msgs__msg__Twist *tw_msg = (const geometry_msgs__msg__Twist *)msgin;

	//remote control

	prev_y = tw_msg->linear.x;

	if(tw_msg->linear.z != 20)
	{
		if (tw_msg->linear.x == 1)
		{
			// forward accel
			TurnLed(TIM_CHANNEL_1, 'w');
			TurnLed(TIM_CHANNEL_2, 'w');
			if(tw_msg->linear.z == 0)
			{
				TurnLed(TIM_CHANNEL_3, 'q');
				TurnLed(TIM_CHANNEL_4, 'q');
			}

			vel1 += 5;
			if(vel1 > 885) vel1 = 885;
			move('f', vel1);
		}

		else if (tw_msg->linear.x == -1)
		{
			// backward accel
			TurnLed(TIM_CHANNEL_3, 'r');
			TurnLed(TIM_CHANNEL_4, 'r');
			if(tw_msg->linear.z == 0)
			{
				TurnLed(TIM_CHANNEL_1, 'q');
				TurnLed(TIM_CHANNEL_2, 'q');
			}
			vel2 -= 5;
			if(vel2 < -885) vel2 = -885;
			move('f', vel2);
		}

		else if (tw_msg->linear.x == 0.5)
		{
			// forward
			TurnLed(TIM_CHANNEL_1, 'w');
			TurnLed(TIM_CHANNEL_2, 'w');
			if(tw_msg->linear.z == 0)
			{
				TurnLed(TIM_CHANNEL_3, 'q');
				TurnLed(TIM_CHANNEL_4, 'q');
			}
			move('f', vel1);
		}

		else if (tw_msg->linear.x == -0.5)
		{
			// backward
			TurnLed(TIM_CHANNEL_3, 'w');
			TurnLed(TIM_CHANNEL_4, 'w');
			if(tw_msg->linear.z == 0)
			{
				TurnLed(TIM_CHANNEL_1, 'q');
				TurnLed(TIM_CHANNEL_2, 'q');
			}
			move('f', vel2);
		}

		else if (tw_msg->linear.x == 0)
		{

			vel1 =  221;
			vel2 =  -221;
			if((uint16_t)(tw_msg->linear.z != 7) && ((uint16_t)tw_msg->linear.z != 8))
			{
				move('s', 0);
			}
		}

		if (tw_msg->angular.z > 0)
		{
			TurnLed(TIM_CHANNEL_2, 'o');
			TurnLed(TIM_CHANNEL_4, 'o');
			Turn(-2);

			if (current_time - last_time >= 600)
			{
				TurnLed(TIM_CHANNEL_2, 'q');
				TurnLed(TIM_CHANNEL_4, 'q');

				last_time = current_time;
			}
		}

		else if (tw_msg->angular.z < 0)
		{
			TurnLed(TIM_CHANNEL_1, 'o');
			TurnLed(TIM_CHANNEL_3, 'o');
			Turn(2);

			if (current_time - last_time >= 600)
			{
				TurnLed(TIM_CHANNEL_1, 'q');
				TurnLed(TIM_CHANNEL_3, 'q');

				last_time = current_time;
			}
		}
		else
		{
			if ((uint16_t)tw_msg->linear.z == 0)
			{
				if(tw_msg->linear.x == 0)
				{
					TurnLed(TIM_CHANNEL_1, 'q');
					TurnLed(TIM_CHANNEL_2, 'q');
					TurnLed(TIM_CHANNEL_3, 'q');
					TurnLed(TIM_CHANNEL_4, 'q');
				}
				ServoOrigin();
			}
			else
			{
				switch((uint16_t)tw_msg->linear.z)
				{
				case 1:
					pos1 = 0;
					pos2 = 0;
					move2(0, 0, 0, 0);
					break;
				case 2:
					pos1 = 2047;
					pos2 = 2047;
					move2(2047, 2047, 2047, 2047);
					break;
				case 4:
					TurnLed(TIM_CHANNEL_1, 'c');
					TurnLed(TIM_CHANNEL_4, 'c');
					TurnLed(TIM_CHANNEL_2, 'w');
					TurnLed(TIM_CHANNEL_3, 'w');
					CrabWalk('l');
					break;
				case 5:
					TurnLed(TIM_CHANNEL_1, 'w');
					TurnLed(TIM_CHANNEL_4, 'w');
					TurnLed(TIM_CHANNEL_2, 'c');
					TurnLed(TIM_CHANNEL_3, 'c');
					CrabWalk('r');
					break;
				case 7:
					Zeromove('l');
					LEDround('l', 'y');

					break;
				case 8:
					Zeromove('r');
					LEDround('r', 'm');
					break;
				case 12:
					pos1 = 0;
					pos2 = 0;
					move4(1024);
					break;

				}
			}

		}
		if (tw_msg->angular.x == 1)
		{
			pos1 += 50;
			if(pos1 > 30000) pos1 = 100000;
			Halfmove('f', pos1);
		}

		else if (tw_msg->angular.x == -1)
		{
			pos1 -= 50;
			if(pos1 < -30000) pos1 = -100000;
			Halfmove('f', pos1);
		}

		else if (tw_msg->angular.x == 2)
		{
			pos2 += 50;
			if(pos2 > 30000) pos2 = 100000;
			Halfmove('b', pos2);
		}

		else if (tw_msg->angular.x == -2)
		{
			pos2 -= 50;
			if(pos2 < -30000) pos2 = -100000;
			Halfmove('b', pos2);
		}
		else if (tw_msg->angular.x == 3)
		{
			pos1 += 50;
			pos2 += 50;
			if(pos1 > 30000) pos1 = 100000;
			if(pos2 > 30000) pos2 = 100000;

			move2(pos1, pos1, pos2, pos2);
		}

		else if (tw_msg->angular.x == -3)
		{
			pos1 -= 50;
			pos2 -= 50;
			if(pos1 < -30000) pos1 = -100000;
			if(pos2 < -30000) pos2 = -100000;

			move2(pos1, pos1, pos2, pos2);
		}
	}

	//auto drive
	else if (tw_msg->linear.z == 20)
	{
		if(tw_msg->linear.x == 30)
		{
			if(prev_y != 30)
			{
				move('s', 0);
				HAL_Delay(500);
			}

			if(tw_msg->angular.z > 0)
			{
				Zeromove('l');
				HAL_Delay(10);
			}
			else
			{
				Zeromove('r');
				HAL_Delay(10);
			}

		}

		else
		{
			if((tw_msg->angular.z >= 10) && (tw_msg->angular.z < 20))
			{
				Wheelturn('l', 2);
				//Turn(2);
			}
			else if((tw_msg->angular.z >= 20) && (tw_msg->angular.z <= 55))
			{
				Wheelturn('l', 2);
				//Turn(2);
			}
			else if((tw_msg->angular.z > -20) && (tw_msg->angular.z <= -10))
			{
				Wheelturn('r', -2);
				//Turn(-2);
			}
			else if((tw_msg->angular.z >= -55) && (tw_msg->angular.z <= -20))
			{
				Wheelturn('r', -2);
				//Turn(-2);
			}
			else
			{
				ServoOrigin();
				move('f', 250);
			}
		}
	}

	HAL_Delay(5);



	/*const std_msgs__msg__Int32 * msg = (const std_msgs__msg__Int32 *)msgin;

	if( msg->data == 0)
	{
		move('s');
	}
	else
	{
		move('f');
	}*/

}

static int previous_msg_data = -1;
static int is_cpt = 0;

void subscription_callback2(const void *msgin)
{
	// Cast the incoming message pointer to the appropriate message type
	const std_msgs__msg__Int32 * msg = (const std_msgs__msg__Int32 *)msgin;
	// Process the message
	// For example, you can access the message fields like this:

		// Process the message
		// For example, you can access the message fields like this:
		switch(msg->data) {
		case 1:
			stpos += 24;
			if(stpos >= 2047) stpos = 2047;
			move3(2000, stpos);
			break;
		case 0:
			if (msg->data != previous_msg_data) {
			previous_msg_data = msg->data;

			move('f', 200);
			}
			US_Read();
			if((is_cpt == 0)&&(Distance <= 2)) {
				is_cpt = 1;
				Halfmove('f',700);
				HAL_Delay(4000);
				Halfmove('b',700);
				HAL_Delay(4000);
				move('s', 0);
				move3(2000, 0);
				move('f', 100);
				HAL_Delay(3000);
				setVel(3500);
				Halfmove('f', 2047);
				HAL_Delay(8000);
				Halfmove('b',2047);
				HAL_Delay(5000);
				move('s', 0);
				HAL_Delay(2000);
				move3(2000, 0);

			}
			break;

		}
		// Add your custom logic here

		// Add your custom logic here
}





/* USER CODE END FunctionPrototypes */

void StartDefaultTask(void *argument);
void StartTask02(void *argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */

	PID_Init(&rollPID, 0.75, 0.005, 0.01);
	PID_Init(&pitchPID, 0.70, 0.001, 0.0005);

  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of defaultTask */
  defaultTaskHandle = osThreadNew(StartDefaultTask, NULL, &defaultTask_attributes);

  /* creation of myTask02 */
  myTask02Handle = osThreadNew(StartTask02, NULL, &myTask02_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* add events, ... */
  /* USER CODE END RTOS_EVENTS */

}

/* USER CODE BEGIN Header_StartDefaultTask */
/**
 * @brief  Function implementing the defaultTask thread.
 * @param  argument: Not used
 * @retval None
 */
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask(void *argument)
{
  /* USER CODE BEGIN StartDefaultTask */
	// micro-ROS configuration


	rmw_uros_set_custom_transport(
			true,
			(void *) &huart2,
			cubemx_transport_open,
			cubemx_transport_close,
			cubemx_transport_write,
			cubemx_transport_read);

	rcl_allocator_t freeRTOS_allocator = rcutils_get_zero_initialized_allocator();
	freeRTOS_allocator.allocate = microros_allocate;
	freeRTOS_allocator.deallocate = microros_deallocate;
	freeRTOS_allocator.reallocate = microros_reallocate;
	freeRTOS_allocator.zero_allocate =  microros_zero_allocate;

	if (!rcutils_set_default_allocator(&freeRTOS_allocator)) {
		printf("Error on default allocators (line %d)\n", __LINE__);
	}

	// micro-ROS app



	//
	allocator = rcl_get_default_allocator();

	//create init_options
	RCCHECK(rclc_support_init(&support, 0, NULL, &allocator));

	// create node
	RCCHECK(rclc_node_init_default(&node, "Hero", "", &support));


	// create publisher
	RCCHECK(rclc_publisher_init_default(
			&publisher,
			&node,
			ROSIDL_GET_MSG_TYPE_SUPPORT(geometry_msgs, msg, Twist),
			"int32_pub"));

	// create subscriber
	RCCHECK(rclc_subscription_init_default(
			&subscriber,
			&node,
			ROSIDL_GET_MSG_TYPE_SUPPORT(geometry_msgs, msg, Twist),
			"cmd_vel"));

	// create another publisher
	RCCHECK(rclc_publisher_init_default(
			&publisher2,
			&node,
			ROSIDL_GET_MSG_TYPE_SUPPORT(std_msgs, msg, Int32),
			"int32_pub2"));

	// create another subscriber
	RCCHECK(rclc_subscription_init_default(
			&subscriber2,
			&node,
			ROSIDL_GET_MSG_TYPE_SUPPORT(std_msgs, msg, Int32),
			"lowest_line_height"));


	// create executor
	RCCHECK(rclc_executor_init(&executor, &support.context, 2, &allocator)); // Note: Increase the number of subscriptions
	RCCHECK(rclc_executor_add_subscription(&executor, &subscriber, &tw_msg, &subscription_callback, ON_NEW_DATA));
	RCCHECK(rclc_executor_add_subscription(&executor, &subscriber2, &msg, &subscription_callback2, ON_NEW_DATA));


  /* Infinite loop */
  for(;;)
  {

	  rcl_ret_t ret = rcl_publish(&publisher, &tw_msg, NULL);
	  if (ret != RCL_RET_OK)
	  {
		  printf("Error publishing (line %d)\n", __LINE__);
	  }

	  rcl_ret_t ret2 = rcl_publish(&publisher2, &msg, NULL);
	  if (ret2 != RCL_RET_OK)
	  {
		  printf("Error publishing (line %d)\n", __LINE__);
	  }

	  RCSOFTCHECK(rclc_executor_spin_some(&executor, RCL_MS_TO_NS(100)));
	  osDelay(3);

  }
  /* USER CODE END StartDefaultTask */
}

/* USER CODE BEGIN Header_StartTask02 */
/**
* @brief Function implementing the myTask02 thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartTask02 */
void StartTask02(void *argument)
{
  /* USER CODE BEGIN StartTask02 */
	/* Infinite loop */
	for(;;)
	{
		if (EBimuAsciiParser(euler, 3)) {

			float leg_positions[4][3];
			calculate_leg_positions(euler, &rollPID, &pitchPID, base_height, leg_positions);

			float desired_angles[4];
			int mapped_angles[4];  // 맵핑된 정수형 배열

			for (int i = 0; i < 4; i++) {
				// 다리 각도 계산
				desired_angles[i] = calculate_leg_angle(leg_positions[i][2]);
				//uartPrintf('2', "Leg %d desired angle: %f\n", i, desired_angles[i]);

				// 0~90 범위의 실수값을 2047~4095 범위의 정수값으로 맵핑
				mapped_angles[i] = qFMathEx_MapMinMaxInt(desired_angles[i], 0.0f, 90.0f, 2047, 4095);
				//uartPrintf('2', "Leg %d mapped angle: %d\n", i, mapped_angles[i]);
			}

			//uartPrintf('2', "%0.2f, %0.2f, %d, %d, %d, %d\n", euler[0], euler[1], mapped_angles[0], mapped_angles[1], mapped_angles[2], mapped_angles[3]);
			move2(mapped_angles[0], -mapped_angles[1], mapped_angles[2], -mapped_angles[3]);
		}

		osDelay(3);
  }
  /* USER CODE END StartTask02 */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */


void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
{

	if (htim->Channel == HAL_TIM_ACTIVE_CHANNEL_1)  // if the interrupt source is channel1
	{
		if (Is_First_Captured==0) // if the first value is not captured
		{
			IC_Val1 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_1); // read the first value
			Is_First_Captured = 1;  // set the first captured as true
			// Now change the polarity to falling edge
			__HAL_TIM_SET_CAPTUREPOLARITY(htim, TIM_CHANNEL_1, TIM_INPUTCHANNELPOLARITY_FALLING);
		}

		else if (Is_First_Captured==1)   // if the first is already captured
		{
			IC_Val2 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_1);  // read second value
			__HAL_TIM_SET_COUNTER(htim, 0);  // reset the counter

			if (IC_Val2 > IC_Val1)
			{
				Difference = IC_Val2 - IC_Val1;
			}

			else if (IC_Val1 > IC_Val2)
			{
				Difference = (0xffff - IC_Val1) + IC_Val2;
			}

			Distance = Difference * .034/2;

			Is_First_Captured = 0; // set it back to false

			if (Distance < 10)
			{
				uartPrintf('2', "dst : %d\n", Distance);

			}


			// set polarity to rising edge
			__HAL_TIM_SET_CAPTUREPOLARITY(htim, TIM_CHANNEL_1, TIM_INPUTCHANNELPOLARITY_RISING);
			__HAL_TIM_DISABLE_IT(&htim3, TIM_IT_CC1);
		}
	}
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	/* USER CODE BEGIN Callback 0 */

  /* USER CODE END Callback 0 */
  if (htim->Instance == TIM2) {
    HAL_IncTick();
  }
  /* USER CODE BEGIN Callback 1 */

  /* USER CODE END Callback 1 */
}
/* USER CODE END Application */

