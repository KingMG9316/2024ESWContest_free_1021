/*
 * qbuffer.h
 *
 *  Created on: Jan 2, 2024
 *      Author: baram
 *      Source: https://github.com/chcbaram/stm32f411/blob/main/stm32f411_fw/src/common/core/qbuffer.c
 */

#ifndef INC_QBUFFER_H_
#define INC_QBUFFER_H_

#include "main.h"
#include "stdbool.h"

typedef struct
{
	uint32_t in;
	uint32_t out;
	uint32_t len;

	uint8_t  *p_buf;
}qbuffer_t;

bool 		qbufferCreate(qbuffer_t *p_node, uint8_t *p_buf, uint32_t length);
bool 		qbufferWrite(qbuffer_t *p_node, uint8_t *p_data, uint32_t length);
bool 		qbufferRead(qbuffer_t *p_node, uint8_t *p_data, uint32_t length);
uint32_t    qbufferAvailable(qbuffer_t *p_node);
void        qbufferFlush(qbuffer_t *p_node);


#endif /* INC_QBUFFER_H_ */
