/*
 * dxl.h
 *
 *  Created on: Jan 7, 2024
 *      Author: baram
 */

#ifndef INC_DXL_H_
#define INC_DXL_H_

#include "main.h"

//Source : https://github.com/chcbaram/stm32f411_exp/blob/main/sdk_fw/hw/driver/dxl.c
//=============================================================================================
#define DXL_PACKET_LEN   512
#define DXL_DEVICE 16
#define DXL_SYNC_WRITE_LEN ((DXL_PACKET_LEN -14 -DXL_DEVICE) / DXL_DEVICE)
#define DXL_BULK_WRITE_LEN ((DXL_PACKET_LEN -14 -DXL_DEVICE * 5)/ DXL_DEVICE)

#define DXL_BROADCAST_ID    254

#define MAX_COMMAND_LENGTH 256



enum
{
	DXL_INST_PING = 0x01,
	DXL_INST_READ = 0x02,
	DXL_INST_WRITE = 0x03,
	DXL_INST_REG_WRITE = 0x04,
	DXL_INST_ACTION = 0x05,
	DXL_INST_FACTORY_RESET = 0x06,
	DXL_INST_REBOOT = 0x08,
	DXL_INST_CLEAR = 0x10,
	DXL_INST_STATUS = 0x55,
	DXL_INST_SYNC_READ = 0x82,
	DXL_INST_SYNC_WRITE = 0x83,
	DXL_INST_BULK_READ = 0x92,
	DXL_INST_BULK_WRITE = 0x93,
};




typedef struct
{
	uint8_t header[3];
	uint8_t reserved;
	uint8_t id;
	uint16_t length;
	uint8_t inst;
	uint8_t err;
	uint16_t param_len;
	uint16_t param_index;
	uint8_t *param;
	uint16_t crc;
} dxl_packet_t;

typedef struct
{
	uint8_t ch;
	uint32_t pre_time;
	uint8_t state;
	uint16_t index;
	bool is_status_packet;

	dxl_packet_t packet;

	uint8_t packet_buf[DXL_PACKET_LEN];
	uint8_t inst_buf[DXL_PACKET_LEN];
} dxl_t;

// ping
typedef struct
{
	uint8_t id;
	uint16_t model_number;
	uint8_t firm_version;
} dxl_ping_node_t;

typedef struct
{
	uint8_t id_cnt;
	dxl_ping_node_t node[DXL_DEVICE];
} dxl_ping_resp_t;

typedef struct
{

	dxl_ping_resp_t resp;

} dxl_ping_t;


// sync_read
typedef struct
{
	uint8_t id_cnt;
	uint16_t addr;
	uint16_t length;


	uint8_t id[DXL_DEVICE];
} dxl_sync_read_param_t;

typedef struct
{
	uint8_t id;
	uint16_t addr;
	uint16_t length;
	uint8_t data[DXL_SYNC_WRITE_LEN];

} dxl_sync_read_node_t;

typedef struct
{
	uint8_t id_cnt;
	dxl_sync_read_node_t node[DXL_DEVICE];

} dxl_sync_read_resp_t;

typedef union
{
	dxl_sync_read_param_t param;
	dxl_sync_read_resp_t resp;

}dxl_sync_read_t;

// sync_write

typedef struct
{
	uint8_t id;
	uint8_t data[DXL_SYNC_WRITE_LEN];

} dxl_sync_write_node_t;

typedef struct
{
	uint8_t id_cnt;
	uint8_t addr;
	uint16_t length;
	dxl_sync_write_node_t node[DXL_DEVICE];

} dxl_sync_write_param_t;

typedef union
{
	dxl_sync_write_param_t param;
}dxl_sync_write_t;

//-- Bulk Read
//
typedef struct
{
  uint8_t  id;
  uint16_t addr;
  uint16_t length;
  uint8_t  data[DXL_BULK_WRITE_LEN];
} dxl_bulk_read_param_node_t;

typedef struct
{
  uint8_t  id_cnt;
  uint8_t  id    [DXL_DEVICE];
  uint16_t addr  [DXL_DEVICE];
  uint16_t length[DXL_DEVICE];
} dxl_bulk_read_param_t;

typedef struct
{
  uint8_t  id;
  uint16_t addr;
  uint16_t length;
  uint8_t  data[DXL_BULK_WRITE_LEN];
} dxl_bulk_read_node_t;

typedef struct
{
  uint8_t id_cnt;
  dxl_bulk_read_node_t  node[DXL_DEVICE];
} dxl_bulk_read_resp_t;

typedef union
{
  dxl_bulk_read_param_t  param;
  dxl_bulk_read_resp_t   resp;
} dxl_bulk_read_t;


//-- Bulk Write
//
typedef struct
{
  uint8_t  id;
  uint16_t addr;
  uint16_t length;
  uint8_t data[DXL_BULK_WRITE_LEN];
} dxl_bulk_write_node_t;

typedef struct
{
  uint8_t  id_cnt;
  dxl_bulk_write_node_t node[DXL_DEVICE];
} dxl_bulk_write_param_t;

typedef union
{
  dxl_bulk_write_param_t  param;
} dxl_bulk_write_t;

typedef union
{
	dxl_ping_t ping;
	dxl_sync_read_t sync_read;
	dxl_sync_write_t sync_write;
	dxl_bulk_read_t  bulk_read;
	dxl_bulk_write_t bulk_write;
}dxl_inst_t;

void dxlInit(void);

bool dxlOpen(dxl_t *p_dxl, uint8_t dxl_ch);

bool dxlInstPing(dxl_t *p_dxl, uint8_t id, dxl_ping_t *p_inst, uint32_t timeout);
bool dxlInstRead(dxl_t *p_dxl, uint8_t id, uint16_t addr, uint8_t *p_data, uint16_t length, uint32_t timeout);
bool dxlInstWrite(dxl_t *p_dxl, uint8_t id, uint16_t addr, uint8_t *p_data, uint16_t length, uint32_t timeout);

bool dxlInstSyncRead(dxl_t *p_dxl, dxl_sync_read_t *p_inst, uint32_t timeout);
bool dxlInstSyncWrite(dxl_t *p_dxl, dxl_sync_write_t *p_inst, uint32_t timeout);

bool dxlInstBulkRead(dxl_t *p_dxl, dxl_bulk_read_t *p_inst, uint32_t timeout);
bool dxlInstBulkWrite(dxl_t *p_dxl, dxl_bulk_write_t *p_inst, uint32_t timeout);

//=============================================================================================

// DXL CLI and control function
void CLI_ProcessCommand(uint8_t ch, int argc, char *argv[]);
void ProcessReceivedData(uint8_t ch);

void enableTorque(void);

void move(uint8_t dir, int32_t vel);
void Zeromove(uint8_t dir);
void Crabmove(uint8_t dir);

void Wheelturn(uint8_t dir, int16_t lv);
void PosOrigin(void);

void setVel(uint32_t vel);
void Halfmove(int8_t prt, int32_t pos);
void move2(int32_t pos1, int32_t pos2, int32_t pos3, int32_t pos4);
void move3(int32_t vel, int32_t pos);
void move4(int32_t pos);
void Velmove(int32_t vel, int32_t pos);
void rnd(int32_t cnt);
void hand(int8_t dir);

#endif /* INC_DXL_H_ */
