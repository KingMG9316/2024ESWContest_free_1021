/*
 * servo.h
 *
 *  Created on: Jan 25, 2024
 *      Author: LG
 */

#ifndef INC_SERVO_H_
#define INC_SERVO_H_

#include "main.h"

void servoInit(void);
void moveServo(uint32_t deg1, uint32_t deg2, uint32_t deg3, uint32_t deg4);

void ServoOrigin(void);

void Turn(int16_t dir);

void CrabWalk(uint8_t dir);

void ZeroTurn(void);

int areAllMotorsAtTarget(void);

#endif /* INC_SERVO_H_ */
