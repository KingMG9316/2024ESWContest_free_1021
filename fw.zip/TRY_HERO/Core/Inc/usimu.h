/*
 * imu.h
 *
 *  Created on: Mar 4, 2024
 *      Author: LG
 */

#ifndef INC_USIMU_H_
#define INC_USIMU_H_

#include "main.h"

typedef struct {
	float Kp;
	float Ki;
	float Kd;
	float prev_error;
	float integral;
} PID;

int EBimuAsciiParser(float *item, uint16_t number_of_item);
void PID_Init(PID *pid, double Kp, double Ki, double Kd);
float PID_Compute(PID *pid,  float setpoint, float measurement);


float calculate_leg_angle(float desired_height);

void calculate_leg_positions(float *euler, PID *rollPID, PID *pitchPID, float base_height, float leg_positions[4][3]);

void US_Read(void);

//LED Control function
void setLED(int LEDnum, uint8_t red, uint8_t green, uint8_t blue);
void setColor(int LEDnum, uint8_t num);
void updateLEDs(uint32_t channel);
void setInitialColors(void);
void blinkcolor(uint8_t cl, uint32_t channel, uint8_t direction, uint32_t* last_time);
void turnOffLED(uint32_t channel, int LEDnum);
void TurnLed(uint32_t channel, uint8_t cl);
void LEDround(uint8_t dir, uint8_t cl);

#endif /* INC_USIMU_H_ */
